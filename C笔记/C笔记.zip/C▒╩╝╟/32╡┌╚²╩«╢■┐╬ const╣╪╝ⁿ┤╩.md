# const关键词

### const修饰指针本身

<img src="C:\Users\Lanson\AppData\Roaming\Typora\typora-user-images\image-20221008230613671.png" alt="image-20221008230613671" style="zoom:50%;" />

<img src="C:\Users\Lanson\AppData\Roaming\Typora\typora-user-images\image-20221008230642015.png" alt="image-20221008230642015" style="zoom:50%;" />

<img src="C:\Users\Lanson\AppData\Roaming\Typora\typora-user-images\image-20221008230705483.png" alt="image-20221008230705483" style="zoom:50%;" />

==const在*左边则修饰指针指向的数据，const在\*右边则修饰指针本身==

<img src="C:\Users\Lanson\AppData\Roaming\Typora\typora-user-images\image-20221008230732035.png" alt="image-20221008230732035" style="zoom:50%;" />





